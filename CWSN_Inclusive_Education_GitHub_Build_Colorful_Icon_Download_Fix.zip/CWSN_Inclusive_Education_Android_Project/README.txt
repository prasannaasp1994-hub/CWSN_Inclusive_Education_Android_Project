CWSN INCLUSIVE EDUCATION ANDROID PROJECT

This Android Studio project wraps the password-protected HTML app in an Android WebView.
App login password: ASP@1994

BUILD APK (requires Android Studio + Android SDK):
1. Extract this ZIP.
2. Open the CWSN_Inclusive_Education_Android_Project folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location (usually app/build/outputs/apk/debug/app-debug.apk).
6. Copy the APK to your Android phone and install it. Allow installation from this source if Android asks.

NOTES:
- Internet permission is included for the configured Google Sheets cloud sync.
- Local HTML storage is retained by WebView on the device.
- The app opens with a login gate. The password check is client-side in the bundled HTML; this is a basic app lock, not enterprise-grade security. Do not treat it as protection against someone who can inspect or modify the APK.
- This source project is not itself an APK. It must be built with Android Studio/Android SDK.

Android download compatibility:
- Blob-based Excel/PNG exports are intercepted inside WebView and saved through Android MediaStore to Downloads/CWSN.
- This avoids passing blob: URLs to Android DownloadManager, which only supports HTTP/HTTPS.
