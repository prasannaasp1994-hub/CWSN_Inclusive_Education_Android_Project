CWSN INCLUSIVE EDUCATION ANDROID PROJECT

GitHub APK build (no computer / Android Studio required after upload):
1. Create a GitHub account and sign in.
2. Create a NEW repository. Choose a name such as cwsn-inclusive-education. Public or Private is your choice.
3. Extract this ZIP. Open the CWSN_Inclusive_Education_Android_Project folder.
4. Upload the CONTENTS of that folder (including app, .github, build.gradle, settings.gradle, gradle.properties) to the repository root. Do not upload the outer folder as an extra nested level.
5. Open the repository's Actions tab.
6. Select "Build CWSN Android APK" and tap "Run workflow" (or wait for the build after pushing to main).
7. Wait until the workflow shows a green check mark.
8. Open the completed workflow run, scroll to Artifacts, and download "CWSN-Inclusive-Education-APK".
9. Extract the downloaded artifact ZIP. It contains app-debug.apk. Install it on Android; allow installation from your browser/files app if prompted.

LOCAL ANDROID STUDIO BUILD:
1. Open this project folder in Android Studio.
2. Use JDK 17 and Android SDK Platform 35.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

APP LOGIN PASSWORD: ASP@1994

NOTES:
- The app wraps the password-protected HTML app in an Android WebView.
- Internet permission is included for configured Google Sheets cloud sync.
- Local HTML storage is retained by WebView on the device.
- The password check is client-side in the bundled HTML. It is a basic app lock, not enterprise-grade security. Do not treat it as protection against someone who can inspect or modify the APK.
- The APK is not prebuilt in this ZIP; GitHub Actions compiles it and publishes it as a downloadable workflow artifact.
